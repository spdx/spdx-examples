# Example package Hello

This package prints out "hello" using logging

## Usage

```
>>> import hello
>>> hello.normal('nisha')
INFO:root:hello nisha
>>> hello.excited('nisha')
WARNING:root:hello nisha!!!
```
