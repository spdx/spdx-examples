# frozen_string_literal: true

require_relative "hello/version"

module Hello
  class Error < StandardError; end
  puts "Hello World!"
end
