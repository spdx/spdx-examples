# frozen_string_literal: true

module Hello
  VERSION = "0.1.0"
end
